from colbert.modeling.tokenization.query_tokenization import *
from colbert.modeling.tokenization.doc_tokenization import *
from colbert.modeling.tokenization.utils import tensorize_triples
